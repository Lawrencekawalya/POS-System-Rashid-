<?php if (isset($component)) { $__componentOriginal81a506f898233b9e7d58286e6bea3c18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81a506f898233b9e7d58286e6bea3c18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::app','data' => ['title' => 'POS Checkout']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'POS Checkout']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="flex flex-col lg:flex-row gap-6">

        <div class="lg:w-1/4">
            <h2 class="text-lg font-bold mb-3 flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path
                        d="M7 3a1 1 0 000 2h6a1 1 0 100-2H7zM4 7a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zM2 11a2 2 0 012-2h12a2 2 0 012 2v4a2 2 0 01-2 2H4a2 2 0 01-2-2v-4z" />
                </svg>
                Current Stock
            </h2>
            <div class="border rounded-lg bg-white shadow-sm overflow-hidden">
                
                    <div class="max-h-[88vh] overflow-y-auto px-2 py-2">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <div class="flex justify-between items-center p-2 border-b last:border-0 hover:bg-gray-50">
                                <div>
                                    <div class="font-medium text-sm text-gray-800"><?php echo e($product->name); ?></div>
                                    <div class="text-xs text-gray-500 font-mono"><?php echo e($product->barcode); ?></div>
                                </div>
                                <div class="text-right">
                                    <!-- <span class="inline-block px-2 py-1 rounded text-xs font-bold <?php echo e($product->total_stock <= 5 ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'); ?>">
                                                                                                    <?php echo e(number_format($product->total_stock)); ?>

                                                                                            </span> -->
                                    <span
                                        class="inline-block px-2 py-1 rounded text-xs font-bold <?php echo e($product->currentStock() <= 5 ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'); ?>">
                                        <?php echo e($product->currentStock()); ?>

                                    </span>
                                </div>
                            </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="lg:w-3/4">
                <h1 class="text-xl font-semibold mb-4">POS Checkout</h1>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
                    <div class="mb-3 p-3 bg-red-50 text-red-600 rounded border border-red-200">
                        <?php echo e($errors->first()); ?>

                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
                    <div class="mb-3 p-3 bg-green-50 text-green-600 rounded border border-green-200">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <!-- <form method="POST" action="<?php echo e(route('pos.add')); ?>" class="mb-4">
                <?php echo csrf_field(); ?>
                <div class="relative">
                    <input type="text" name="barcode" autofocus placeholder="Scan barcode..."
                        class="border-2 border-gray-300 px-4 py-3 w-full rounded-lg focus:border-black focus:outline-none text-lg">
                    <div class="absolute right-3 top-3 text-gray-400">
                        <kbd class="bg-gray-100 px-2 py-1 rounded border text-xs">Enter</kbd>
                    </div>
                </div>
            </form> -->
                <form method="POST" action="<?php echo e(route('pos.add')); ?>" class="mb-4">
                    <?php echo csrf_field(); ?>
                    <div class="relative">
                        <input list="product-list" name="barcode" autofocus
                            placeholder="Search product or scan barcode..."
                            class="border-2 border-gray-300 px-4 py-3 w-full rounded-lg focus:border-black focus:outline-none text-lg">

                        <datalist id="product-list">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <option value="<?php echo e($product->barcode); ?>"><?php echo e($product->name); ?> (Stock:
                                    <?php echo e($product->currentStock()); ?>)
                                </option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </datalist>

                        <div class="absolute right-3 top-3 text-gray-400">
                            <kbd class="bg-gray-100 px-2 py-1 rounded border text-xs">Enter</kbd>
                        </div>
                    </div>
                </form>

                <div class="border rounded-lg bg-white overflow-hidden mb-4 shadow-sm">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-gray-50 border-b">
                                <th class="px-4 py-3 font-semibold text-gray-700">Product</th>
                                <th class="px-4 py-3 font-semibold text-gray-700 text-center">Qty</th>
                                <th class="px-4 py-3 font-semibold text-gray-700 text-right">Price</th>
                                <th class="px-4 py-3 font-semibold text-gray-700 text-right">Subtotal</th>
                                <th class="px-4 py-3 font-semibold text-gray-700 text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                
                                <tr data-product-id="<?php echo e($item['product_id']); ?>">
                                    <td class="px-4 py-3"><?php echo e($item['name']); ?></td>
                                    <td class="px-4 py-3 text-center">
                                        <div class="flex items-center justify-center gap-2">
                                            

                                            <form method="POST"
                                                action="<?php echo e(route('pos.updateQuantity', $item['product_id'])); ?>"
                                                id="update-qty-<?php echo e($item['product_id']); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="number" name="quantity" value="<?php echo e($item['quantity']); ?>" min="1"
                                                    class="qty-input w-16 h-8 text-center font-bold border-gray-300 rounded"
                                                    onblur="this.form.submit()"> 
                                            </form>
                                        </div>
                                    </td>

                                    
                                    <td class="px-4 py-3 text-right unit-price" data-price="<?php echo e($item['unit_price']); ?>">
                                        <?php echo e(number_format($item['unit_price'], 2)); ?>

                                    </td>

                                    
                                    <td class="px-4 py-3 text-right font-semibold subtotal-display">
                                        <?php echo e(number_format($item['subtotal'], 2)); ?>

                                    </td>
                                    <td class="px-4 py-3 text-center">
                                        <form method="POST" action="<?php echo e(route('pos.remove', $item['product_id'])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button
                                                class="text-red-500 hover:text-red-700 text-sm font-medium">Remove</button>
                                        </form>
                                    </td>
                                </tr>
                                
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                <tr>
                                    <td colspan="5" class="text-center py-12 text-gray-400">Scan items to build the cart.
                                    </td>
                                </tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="flex flex-col md:flex-row gap-4 items-start mb-10">
                    
                    <div class="text-3xl font-bold">
                        
                        Total: <span id="grand-total" class="text-blue-600" data-total="<?php echo e($total); ?>">
                            <?php echo e(number_format($total, 2)); ?>

                        </span>
                    </div>

                    <div class="w-full md:w-80">
                        <form method="POST" action="<?php echo e(route('pos.checkout')); ?>" class="space-y-2">
                            <?php echo csrf_field(); ?>
                            <input type="number" name="paid_amount" step="0.01" placeholder="Cash received"
                                class="border-2 border-gray-300 px-4 py-3 w-full rounded-lg text-xl focus:border-green-500 focus:outline-none">
                            <button
                                class="bg-green-600 hover:bg-green-700 text-white font-bold px-4 py-4 w-full rounded-lg shadow-lg transition">
                                COMPLETE SALE
                            </button>
                        </form>
                    </div>
                </div>

                <hr class="my-10 border-gray-300">

                <!-- <h2 class="text-lg font-semibold mb-4">Today’s Sales Summary</h2> -->
                <!-- <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div class="p-4 bg-white border rounded-lg shadow-sm">
                    <div class="text-gray-500 text-xs uppercase tracking-wider font-bold">Total Sales</div>
                    <div class="text-2xl font-bold"><?php echo e(number_format($totalSales, 2)); ?></div>
                </div>
                <div class="p-4 bg-white border rounded-lg shadow-sm">
                    <div class="text-gray-500 text-xs uppercase tracking-wider font-bold">Refunds</div>
                    <div class="text-2xl font-bold text-red-600"><?php echo e(number_format($totalRefunds, 2)); ?></div>
                </div>
                <div class="p-4 bg-white border rounded-lg shadow-sm border-l-4 border-l-green-500">
                    <div class="text-gray-500 text-xs uppercase tracking-wider font-bold">Net Revenue</div>
                    <div class="text-2xl font-bold"><?php echo e(number_format($netTotal, 2)); ?></div>
                </div>
            </div> -->
                <h2 class="text-lg font-semibold mb-4">Sales Performance</h2>
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                    <div class="p-4 bg-white border rounded-lg shadow-sm">
                        <div class="text-gray-500 text-xs uppercase tracking-wider font-bold">Today's Sales</div>
                        <div class="text-2xl font-bold"><?php echo e(number_format($totalSales, 2)); ?></div>
                    </div>

                    <div class="p-4 bg-white border rounded-lg shadow-sm">
                        <div class="text-gray-500 text-xs uppercase tracking-wider font-bold">Refunds</div>
                        <div class="text-2xl font-bold text-red-600"><?php echo e(number_format($totalRefunds, 2)); ?></div>
                    </div>

                    <div class="p-4 bg-white border rounded-lg shadow-sm">
                        <div class="text-gray-500 text-xs uppercase tracking-wider font-bold">Today's Net</div>
                        <div class="text-2xl font-bold text-green-600"><?php echo e(number_format($netTotal, 2)); ?></div>
                    </div>

                    <div class="p-4 bg-black text-white border rounded-lg shadow-sm">
                        <div class="text-gray-400 text-xs uppercase tracking-wider font-bold">Cumulative Revenue</div>
                        <div class="text-2xl font-bold text-blue-400"><?php echo e(number_format($cumulativeRevenue, 2)); ?></div>
                    </div>
                </div>

                <hr class="my-10 border-gray-300">
                <h2 class="text-lg font-semibold mb-4">Today's Sales</h2>

                <!-- <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($salesToday->count()): ?>
                <div class="overflow-x-auto border rounded-lg shadow-sm bg-white">
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="bg-gray-50 border-b">
                                <th class="px-4 py-3 text-left font-semibold text-gray-700">Receipt</th>
                                <th class="px-4 py-3 text-left font-semibold text-gray-700">Time</th>
                                <th class="px-4 py-3 text-right font-semibold text-gray-700">Amount</th>
                                <th class="px-4 py-3 text-center font-semibold text-gray-700">Status</th>
                                <th class="px-4 py-3 text-center font-semibold text-gray-700">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $salesToday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <tr class="hover:bg-gray-50 transition">
                                    <td class="px-4 py-3 font-medium text-gray-900">
                                        #<?php echo e($sale->id); ?>

                                    </td>
                                    <td class="px-4 py-3 text-gray-600">
                                        <?php echo e($sale->created_at->format('H:i')); ?>

                                    </td>
                                    <td class="px-4 py-3 text-right font-mono">
                                        <?php echo e(number_format($sale->total_amount, 2)); ?>

                                    </td>
                                    <td class="px-4 py-3 text-center">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sale->isRefunded()): ?>
                                            <span
                                                class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                                Refunded
                                            </span>
                                        <?php else: ?>
                                            <span
                                                class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                Sold
                                            </span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                    <td class="px-4 py-3 text-center">
                                        <a href="<?php echo e(route('sales.show', $sale)); ?>"
                                            class="text-blue-600 hover:text-blue-900 font-semibold">
                                            View
                                        </a>
                                    </td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="p-8 text-center border-2 border-dashed rounded-lg bg-gray-50">
                    <p class="text-gray-500">No sales recorded today.</p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?> -->
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($salesToday->count()): ?>
                    <div class="overflow-x-auto border rounded-lg shadow-sm bg-white">
                        <table class="w-full text-sm text-left">
                            <thead>
                                <tr class="bg-gray-50 border-b">
                                    <th class="px-4 py-3 font-semibold text-gray-700">Receipt</th>
                                    <th class="px-4 py-3 font-semibold text-gray-700">Time</th>
                                    <th class="px-4 py-3 text-right font-semibold text-gray-700">Amount</th>
                                    <th class="px-4 py-3 text-center font-semibold text-gray-700">Status</th>
                                    <th class="px-4 py-3 text-center font-semibold text-gray-700">Action</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $salesToday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                    <tr class="hover:bg-gray-50 transition">
                                        <td class="px-4 py-3 font-medium text-gray-900">#<?php echo e($sale->id); ?></td>
                                        <td class="px-4 py-3 text-gray-600"><?php echo e($sale->created_at->format('H:i')); ?></td>
                                        <td class="px-4 py-3 text-right font-mono"><?php echo e(number_format($sale->total_amount, 2)); ?>

                                        </td>
                                        <td class="px-4 py-3 text-center">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sale->isRefunded()): ?>
                                                <span
                                                    class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                                    Refunded
                                                </span>
                                            <?php else: ?>
                                                <span
                                                    class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                    Sold
                                                </span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </td>
                                        <td class="px-4 py-3 text-center">
                                            <a href="<?php echo e(route('sales.show', $sale)); ?>"
                                                class="text-blue-600 hover:text-blue-900 font-semibold">
                                                View
                                            </a>
                                        </td>
                                    </tr>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </tbody>
                            <tfoot class="bg-gray-50 border-t-2 border-gray-200">
                                <tr>
                                    <td colspan="2" class="px-4 py-3 text-right font-bold text-gray-700">Total Today:</td>
                                    <td class="px-4 py-3 text-right font-bold text-gray-900 font-mono text-base">
                                        <?php echo e(number_format($salesToday->sum('total_amount'), 2)); ?>

                                    </td>
                                    <td colspan="2" class="bg-gray-50"></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="p-8 text-center border-2 border-dashed rounded-lg bg-gray-50">
                        <p class="text-gray-500">No sales recorded today.</p>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
        <script>
            // 1. Define the calculator function separately so it's reusable
            function updateTotals() {
                let grandTotal = 0;

                document.querySelectorAll('tr[data-product-id]').forEach(row => {
                    const qtyInput = row.querySelector('.qty-input');
                    const subtotalDisplay = row.querySelector('.subtotal-display');
                    const priceAttr = row.querySelector('.unit-price').dataset.price;

                    if (!qtyInput || !subtotalDisplay) return;

                    const qty = parseFloat(qtyInput.value) || 0;
                    const price = parseFloat(priceAttr) || 0;
                    const subtotal = qty * price;

                    grandTotal += subtotal;

                    // Update individual row subtotal text
                    subtotalDisplay.innerText = new Intl.NumberFormat('en-US', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    }).format(subtotal);
                });

                // 2. Update the Grand Total display
                const grandTotalDisplay = document.getElementById('grand-total');
                if (grandTotalDisplay) {
                    grandTotalDisplay.innerText = new Intl.NumberFormat('en-US', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    }).format(grandTotal);
                }
            }

            // 3. Attach the event listener to all inputs once
            document.querySelectorAll('.qty-input').forEach(input => {
                input.addEventListener('input', updateTotals);
            });
        </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81a506f898233b9e7d58286e6bea3c18)): ?>
<?php $attributes = $__attributesOriginal81a506f898233b9e7d58286e6bea3c18; ?>
<?php unset($__attributesOriginal81a506f898233b9e7d58286e6bea3c18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81a506f898233b9e7d58286e6bea3c18)): ?>
<?php $component = $__componentOriginal81a506f898233b9e7d58286e6bea3c18; ?>
<?php unset($__componentOriginal81a506f898233b9e7d58286e6bea3c18); ?>
<?php endif; ?>
<?php /**PATH A:\Projects\Laravel\client2\client2\resources\views/pos/index.blade.php ENDPATH**/ ?>