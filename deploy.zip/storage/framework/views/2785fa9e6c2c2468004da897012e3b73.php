<div class="rounded-xl border border-neutral-200 dark:border-neutral-700 p-4">
    <div class="text-sm text-neutral-500 mb-1">
        <?php echo e($label); ?>

    </div>

    <div class="text-2xl font-semibold">
        <?php echo e($value); ?>

    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($subtext)): ?>
        <div class="text-xs text-neutral-400 mt-1">
            <?php echo e($subtext); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH /var/www/client1/resources/views/components/dashboard/kpi-card.blade.php ENDPATH**/ ?>