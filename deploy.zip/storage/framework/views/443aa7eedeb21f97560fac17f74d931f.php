



<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" <?php echo e($attributes); ?>>
    <path d="M35 85 L65 15" stroke="currentColor" stroke-width="3" stroke-linecap="round" />

    <path fill="currentColor" d="M15 65 L28 25 L35 25 L42 65 H37 L35 55 H22 L20 65 H15 Z M24 48 H33 L28 32 L24 48 Z" />

    <path fill="currentColor"
        d="M50 85 V45 H65 C72 45 75 48 75 55 C75 60 72 63 67 64 L77 85 H71 L62 65 H56 V85 H50 Z M56 60 H63 C68 60 70 58 70 54 C70 50 68 49 63 49 H56 V60 Z" />
</svg><?php /**PATH A:\Projects\Laravel\client2\client2\resources\views/components/app-logo-icon.blade.php ENDPATH**/ ?>