

<div <?php echo e($attributes->class('flex-1 pointer-events-none')); ?> data-flux-sidebar-spacer></div><?php /**PATH /var/www/client1/vendor/livewire/flux/stubs/resources/views/flux/sidebar/spacer.blade.php ENDPATH**/ ?>