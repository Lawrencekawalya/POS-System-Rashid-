

<?php if (isset($component)) { $__componentOriginal81a506f898233b9e7d58286e6bea3c18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81a506f898233b9e7d58286e6bea3c18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::app','data' => ['title' => 'Z-Report']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Z-Report']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>


    <div class="print:hidden flex justify-between mb-4">
        <form method="GET" class="flex gap-2 items-end">
            <div>
                <label class="text-xs font-bold text-gray-500">From</label>
                <input type="date" name="start_date" value="<?php echo e($startDate); ?>"
                    class="border px-2 py-1 rounded text-sm focus:ring-2 focus:ring-black">
            </div>

            <div>
                <label class="text-xs font-bold text-gray-500">To</label>
                <input type="date" name="end_date" value="<?php echo e($endDate); ?>"
                    class="border px-2 py-1 rounded text-sm focus:ring-2 focus:ring-black">
            </div>

            <button class="px-4 py-1 bg-black text-white rounded text-sm hover:bg-gray-800 transition">
                View
            </button>
        </form>

        <button onclick="window.print()" class="px-4 py-1 bg-indigo-600 text-white rounded text-sm hover:bg-indigo-700 transition">
            Print Report
        </button>
    </div>

    <div class="thermal-receipt mx-auto shadow-sm border border-gray-100">

        <h1 class="text-center font-bold text-lg mb-1">Z REPORT</h1>
        <p class="text-center text-[10px] uppercase tracking-widest mb-2 underline">Financial Summary</p>
        
        <p class="text-center text-[10px] mb-2 border-y border-dashed py-1">
            <?php echo e(\Carbon\Carbon::parse($startDate)->format('d M Y')); ?> → <?php echo e(\Carbon\Carbon::parse($endDate)->format('d M Y')); ?>

        </p>

        <div class="text-xs space-y-1 mt-3">
            <div class="flex justify-between">
                <span>Gross Sales</span>
                <span><?php echo e(number_format($grossSales)); ?></span>
            </div>

            <div class="flex justify-between text-red-600 italic">
                <span>Total Refunds</span>
                <span>-<?php echo e(number_format($refundTotal)); ?></span>
            </div>

            <div class="flex justify-between font-bold border-t border-black pt-1 mt-1">
                <span>Net Sales</span>
                <span><?php echo e(number_format($netSales)); ?></span>
            </div>

            
            <div class="flex justify-between text-red-600 italic">
                <span>Confirmed Expenses</span>
                <span>-<?php echo e(number_format($totalExpenses)); ?></span>
            </div>

            <div class="flex justify-between font-bold border-t-2 border-black pt-1 mt-2 text-sm bg-gray-50 px-1">
                <span>CASH EXPECTED</span>
                <span><?php echo e(number_format($cashExpected)); ?></span>
            </div>
        </div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($expenses->count() > 0): ?>
            <div class="mt-4">
                <p class="text-[10px] font-bold border-b border-dashed mb-1">VERIFIED PAYOUTS</p>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                    <div class="flex justify-between text-[10px]">
                        <span class="truncate mr-2"><?php echo e($expense->category); ?> (<?php echo e($expense->user->name ?? 'Staff'); ?>)</span>
                        <span><?php echo e(number_format($expense->amount)); ?></span>
                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <?php
            $pendingExpenses = \App\Models\Expense::whereBetween('expense_date', [$startDate, $endDate])
                                ->where('status', 'pending')->get();
        ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pendingExpenses->count() > 0): ?>
            <div class="mt-4 p-2 bg-yellow-50 border border-yellow-200 print:bg-transparent print:border-black">
                <p class="text-[9px] font-bold text-yellow-800 uppercase print:text-black italic underline">
                    * Pending Review (Not in Total)
                </p>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $pendingExpenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                    <div class="flex justify-between text-[9px] text-yellow-700 print:text-black">
                        <span><?php echo e($pending->category); ?></span>
                        <span><?php echo e(number_format($pending->amount)); ?></span>
                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="mt-6 border-t border-dashed pt-2 text-center text-[9px] text-gray-500 italic">
            <p>Generated by: <?php echo e(auth()->user()->name); ?></p>
            <p><?php echo e(now()->format('Y-m-d H:i:s')); ?></p>
        </div>

    </div>

    

    <style>
        .thermal-receipt {
            width: 80mm;
            margin: 0 auto;
            font-family: monospace;
            font-size: 12px;
            color: black;
            background: white;
        }

        @media print {

            @page {
                size: 80mm auto;
                /* THIS IS THE IMPORTANT PART */
                margin: 0;
            }

            html,
            body {
                width: 80mm;
                margin: 0;
                padding: 0;
                background: white;
            }

            body * {
                visibility: hidden;
            }

            .thermal-receipt,
            .thermal-receipt * {
                visibility: visible;
            }

            .thermal-receipt {
                position: absolute;
                left: 0;
                top: 0;
            }
        }
    </style>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81a506f898233b9e7d58286e6bea3c18)): ?>
<?php $attributes = $__attributesOriginal81a506f898233b9e7d58286e6bea3c18; ?>
<?php unset($__attributesOriginal81a506f898233b9e7d58286e6bea3c18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81a506f898233b9e7d58286e6bea3c18)): ?>
<?php $component = $__componentOriginal81a506f898233b9e7d58286e6bea3c18; ?>
<?php unset($__componentOriginal81a506f898233b9e7d58286e6bea3c18); ?>
<?php endif; ?>
<?php /**PATH /var/www/client1/resources/views/reports/z-report.blade.php ENDPATH**/ ?>