

<div <?php echo e($attributes->class('text-sm')); ?> data-slot="text">
    <?php echo e($slot); ?>

</div>
<?php /**PATH /var/www/client1/vendor/livewire/flux/stubs/resources/views/flux/callout/text.blade.php ENDPATH**/ ?>