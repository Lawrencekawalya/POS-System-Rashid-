

<div <?php echo e($attributes->class('flex items-center justify-between gap-2 min-h-10')); ?> data-flux-sidebar-header>
    <?php echo e($slot); ?>

</div><?php /**PATH /var/www/client1/vendor/livewire/flux/stubs/resources/views/flux/sidebar/header.blade.php ENDPATH**/ ?>