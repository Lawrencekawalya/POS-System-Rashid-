<?php if (isset($component)) { $__componentOriginal81a506f898233b9e7d58286e6bea3c18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81a506f898233b9e7d58286e6bea3c18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::app','data' => ['title' => 'Refund Receipt']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Refund Receipt']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>


    
    <div class="flex justify-between mb-4 print:hidden">
        <a href="<?php echo e(route('sales.show', $sale)); ?>" class="px-3 py-1 bg-gray-200 rounded text-sm">
            ← Back to Receipt
        </a>

        <button onclick="window.print()" class="px-3 py-1 bg-black text-white rounded text-sm">
            Print
        </button>
    </div>

    
    <div class="thermal-receipt mx-auto">

        <div class="text-center mb-2">
            <h1 class="font-bold text-base">Palace Hotel</h1>
            <p class="text-xs">Mbarara, Uganda</p>
            <p class="text-xs font-semibold">REFUND RECEIPT</p>
            <p class="text-xs">Refund #<?php echo e($refund->id); ?></p>
            <p class="text-xs">Sale #<?php echo e($sale->id); ?></p>
            <p class="text-xs"><?php echo e($refund->created_at->format('Y-m-d H:i')); ?></p>
            <p class="text-xs">Cashier: <?php echo e($sale->user->name); ?></p>
        </div>

        <hr class="my-1">

        <table class="w-full text-xs">
            <thead>
                <tr>
                    <th class="text-left">Item</th>
                    <th class="text-center">Qty</th>
                    <th class="text-right">Amt</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo e($refund->product->name); ?></td>
                    <td class="text-center"><?php echo e($refund->quantity); ?></td>
                    <td class="text-right"><?php echo e(number_format($refund->amount, 0)); ?></td>
                </tr>
            </tbody>
        </table>

        <hr class="my-1">

        <div class="text-xs space-y-1">
            <div class="flex justify-between font-semibold">
                <span>Refund Total</span>
                <span><?php echo e(number_format($refund->amount, 0)); ?></span>
            </div>
        </div>

        <hr class="my-2">

        <p class="text-xs">
            Reason: <?php echo e($refund->reason); ?>

        </p>

        <p class="mt-4 text-center text-xs">
            Refunded items returned to stock
        </p>
    </div>

    <style>
        .thermal-receipt {
            width: 80mm;
            margin: 0 auto;
            font-family: monospace;
            font-size: 12px;
            color: black;
            background: white;
        }

        @media print {

            @page {
                size: 80mm auto;
                /* THIS IS THE IMPORTANT PART */
                margin: 0;
            }

            html,
            body {
                width: 80mm;
                margin: 0;
                padding: 0;
                background: white;
            }

            body * {
                visibility: hidden;
            }

            .thermal-receipt,
            .thermal-receipt * {
                visibility: visible;
            }

            .thermal-receipt {
                position: absolute;
                left: 0;
                top: 0;
            }
        }
    </style>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81a506f898233b9e7d58286e6bea3c18)): ?>
<?php $attributes = $__attributesOriginal81a506f898233b9e7d58286e6bea3c18; ?>
<?php unset($__attributesOriginal81a506f898233b9e7d58286e6bea3c18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81a506f898233b9e7d58286e6bea3c18)): ?>
<?php $component = $__componentOriginal81a506f898233b9e7d58286e6bea3c18; ?>
<?php unset($__componentOriginal81a506f898233b9e7d58286e6bea3c18); ?>
<?php endif; ?>
<?php /**PATH /var/www/client1/resources/views/sales/refund-receipt.blade.php ENDPATH**/ ?>